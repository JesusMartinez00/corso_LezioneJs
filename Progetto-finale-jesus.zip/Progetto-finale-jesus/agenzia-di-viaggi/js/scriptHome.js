// document.addEventListener("DOMContentLoaded", function() {
//     let card1 = document.querySelector("#card1");
//     let card2 = document.querySelector("#card2");
//     let card3 = document.querySelector("#card3");
//     let card4 = document.querySelector("#card4");


//     let destinazioni = [];

//     function recuperaDati() {
//         const URLEndpoint = `https://www.freetestapi.com/api/v1/destinations`;

//         fetch(URLEndpoint)
//         .then(response =>{
//             return response.json();
//         })
//         .then(data => {
//             destinazioni = data;
//             data.forEach((destinazione, index) => {
//                 let cardHTML = creaCard(destinazione, index);
//                 cardsContainer.innerHTML +=  cardHTML;
//             });
//         })
//         .catch(error => console.error('Errore durante il recupero dei dati:', error));
//     }
//         .then(data =>{
//             console.log(destinazioni);
            
//             destinazioni = data;
//             data.forEach(destinazione => {
//                 destinazioni.push(destinazione);
//             });

//             console.log(destinazioni);
//             card1.innerHTML = creaCard(destinazioni[0]);
//             card2.innerHTML = creaCard(destinazioni[1]);
//             card3.innerHTML = creaCard(destinazioni[2]);
//             card4.innerHTML = creaCard(destinazioni[3]);
            

            
//         })
//         .catch(error => console.error('Errore durante il recupero dei dati:', error));
//     }

    
//     function creaCard(destinazione, index) {
//         return `
//             <div class="card">
//                 <img src="${destinazione.image}" class="card-img-top" alt="${destinazione.name}">
//                 <div class="card-body">
//                     <h5 class="card-title">${destinazione.name}</h5>
//                     <p class="card-text">${destinazione.description || 'Descrizione non disponibile'}</p>
//                     <button class="btn btn-primary" onclick="prenota(${index})">Prenota</button>
//                 </div>
//             </div>
//         `;
//     }
//     funtion prenota(index) {
//         localStorage.setItem('destinazione', JSON.stringify(destinazioni[index]));
//         location.href = '';
//     }

//     recuperaDati();
// });



document.addEventListener("DOMContentLoaded", function() {
    let cardsContainer = document.querySelector('#cards-container');
    let destinazioni = [];

    function recuperaDati() {
        const URLEndpoint = `https://www.freetestapi.com/api/v1/destinations`;

        fetch(URLEndpoint)
        .then(response => {
            if (!response.ok) {
                throw new Error('Errore nella richiesta API');
            }
            return response.json();
        })
        .then(data => {
            destinazioni = data;
            data.slice(0, 6).forEach((destinazione, index) => {
                let cardHTML = creaCard(destinazione, index);
                cardsContainer.innerHTML += cardHTML;
            });

            console.log(destinazioni);
            
        })
        .catch(error => console.error('Errore durante il recupero dei dati:', error));
    }

    // Funzione per creare la card come stringa HTML
    function creaCard(destinazione, index) {
        return `
            <div class="col-md-4 mb-4">
                <div class="card h-100 transition shadow p-3 mb-5 bg-body-tertiary rounded border border-0">
                    <img src="${destinazione.image}" class="img-fuid" alt="${destinazione.name}">
                    <div class="card-body">
                        <h5 class="card-title">${destinazione.name}</h5>
                        <p class="card-text">${destinazione.description || 'Descrizione non disponibile'}</p>
                        <button class="btn btn-primary" onclick="prenota(${index})">Prenota</button>
                    </div>
                </div>
            </div>
        `;
    }

    // Funzione per memorizzare i dati nel localStorage e aprire la pagina di dettaglio
    window.prenota = function(index) {
        localStorage.setItem('destinazione', JSON.stringify(destinazioni[index]));
        window.location.href = 'dettaglioViaggio.html';
    }

    // Recupera i dati al caricamento della pagina
    recuperaDati();
});




